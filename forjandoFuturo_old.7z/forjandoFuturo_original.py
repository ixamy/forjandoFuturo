# Simulating the game with a predefined list of decisions
# Let's redefine the class JuegoSupervivencia with the modified version including 'forjar' action

class JuegoSupervivencia:
    def __init__(self):
        self.epoca = "Prehistoria"
        self.recursos = {"comida": 10, "madera": 5, "herramientas": 0}
        self.habilidades = {"cazar": False, "hacer_fuego": False, "construir": False, "forjar": False}
        self.eventos = []
    
    def mostrar_estado(self):
        print(f"📜 Época actual: {self.epoca}")
        print(f"🌿 Recursos: {self.recursos}")
        habs = [k for k, v in self.habilidades.items() if v]
        print(f"🛠️ Habilidades: {', '.join(habs) if habs else 'Ninguna adquirida'}")
        print("----------------------------------")
    
    def avanzar(self):
        if self.epoca == "Prehistoria" and self.habilidades["hacer_fuego"] and self.habilidades["cazar"]:
            self.epoca = "Edad de Piedra"
            self.recursos["herramientas"] += 2
            self.eventos.append("Descubriste herramientas rudimentarias de piedra")
        elif self.epoca == "Edad de Piedra" and self.habilidades["construir"]:
            self.epoca = "Edad de los Metales"
            self.recursos["madera"] += 10
            self.eventos.append("Aprendiste a construir viviendas más resistentes")
        elif self.epoca == "Edad de los Metales" and self.habilidades["forjar"]:
            self.epoca = "Edad Media"
            self.eventos.append("Has dado paso a una sociedad con castillos y forja de armas")
        else:
            self.eventos.append("Aún no puedes avanzar de época, necesitas más descubrimientos")
    
    def tomar_decision(self, decision):
        if decision == "cazar":
            if not self.habilidades["cazar"]:
                self.habilidades["cazar"] = True
                self.recursos["comida"] += 5
                self.eventos.append("Aprendiste a cazar, ahora obtienes más comida")
            else:
                self.eventos.append("Ya dominas la caza")
        elif decision == "hacer fuego":
            if not self.habilidades["hacer_fuego"]:
                self.habilidades["hacer_fuego"] = True
                self.recursos["comida"] += 3
                self.eventos.append("Has descubierto cómo hacer fuego, mejora tu supervivencia")
            else:
                self.eventos.append("Ya sabes hacer fuego")
        elif decision == "construir":
            if not self.habilidades["construir"]:
                self.habilidades["construir"] = True
                self.recursos["madera"] += 5
                self.eventos.append("Aprendiste a construir refugios más duraderos")
            else:
                self.eventos.append("Ya dominas la construcción")
        elif decision == "forjar":
            if self.epoca == "Edad de los Metales":
                if not self.habilidades["forjar"]:
                    self.habilidades["forjar"] = True
                    self.recursos["herramientas"] += 4
                    self.eventos.append("Has aprendido a forjar metales, mejorando tus herramientas")
                else:
                    self.eventos.append("Ya sabes forjar")
            else:
                self.eventos.append("No puedes forjar en esta época")
        else:
            self.eventos.append("Esa acción no es válida")
        
    def jugar(self):
        print("🌍 ¡Bienvenido a la aventura de la supervivencia y evolución!")
        while self.epoca != "Edad Media":
            self.mostrar_estado()
            try:
                decision = input("¿Qué quieres hacer? (cazar, hacer fuego, construir, forjar, avanzar): ").lower()
            except EOFError:
                print("⚠️ No se puede leer la entrada en este entorno. Usa una lista predefinida de decisiones.")
                break
            
            if decision == "avanzar":
                self.avanzar()
            else:
                self.tomar_decision(decision)
        print("🎉 ¡Has llegado a la Edad Media y evolucionado tu civilización!")
        print("Eventos:")
        for evento in self.eventos:
            print(" -", evento)

# Execute the game simulation
juego = JuegoSupervivencia()
juego.jugar()