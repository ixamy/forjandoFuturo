import time
import os
import random

class JuegoSupervivencia:
    def __init__(self):
        self.epoca = "Prehistoria"
        self.recursos = {
            "comida": random.randrange(5, 15, 5),
            "madera": random.randrange(5, 15, 5),
        }

        self.habilidades = {
            "cazar": False,
            "talar": False
        }
        self.eventos = []
        self.nueva_epoca = False  # Controla si se ha avanzado de época recientemente
    
    def mostrar_estado(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        
        estrella = "⭐" if self.nueva_epoca else ""
        print(f"\n📜 Época actual: {self.epoca} {estrella}\n")
        print("🌿 Recursos:")
        for k, v in self.recursos.items():
            print(f"   - {k.capitalize().replace('_', ' ')}: {v}")
        print("\n🛠️ Habilidades:")
        habilidades_str = ", ".join([k.replace('_', ' ') for k, v in self.habilidades.items() if v]) if any(self.habilidades.values()) else "Ninguna adquirida"
        print(f"   {habilidades_str}\n")
        
        print("📜 Eventos recientes:")
        for evento in self.eventos[-10:]:  # Mostrar los últimos 10 eventos
            print(f"   - {evento}")
        print("\n")
        
    def avanzar(self):
        if self.epoca == "Prehistoria" and self.habilidades["cazar"] and self.recursos["comida"] >= 20:
            self.epoca = "Edad de Piedra"
            self.registrar_evento(f"Avanzaste a {self.epoca}")
            self.nueva_epoca = True
        elif self.epoca == "Edad de Piedra" and self.recursos["comida"] >= 50:
            self.epoca = "Edad de los Metales"
            self.registrar_evento(f"Avanzaste a {self.epoca}")
            self.nueva_epoca = True
        elif self.epoca == "Edad de los Metales" and self.recursos["comida"] >= 80:
            self.epoca = "Edad Media"
            self.registrar_evento(f"Avanzaste a {self.epoca}")
            self.nueva_epoca = True
        else:
            self.registrar_evento("Aún no puedes avanzar de época")
    
    def aprender_habilidad(self, habilidad):
        if habilidad in self.habilidades:
            if not self.habilidades[habilidad]:
                self.habilidades[habilidad] = True
                self.registrar_evento(f"Aprendiste a {habilidad}")
            else:
                self.registrar_evento(f"Ya sabes {habilidad}")
        else:
            self.registrar_evento("Esa habilidad no existe")
    
    def tomar_decision(self, decision):
        self.nueva_epoca = False  # Se desactiva la estrella después de ejecutar una acción

        # Manejo flexible de comandos
        partes = decision.split()
        if len(partes) == 2 and partes[0] == "aprender":
            habilidad = partes[1]
            self.aprender_habilidad(habilidad)

        elif decision == "cazar":
            if self.habilidades["cazar"]:
                self.actualizar_recurso("comida", 10, "Obtienes carne cazando")
            else:
                self.registrar_evento("No sabes cazar aún, aprende la habilidad primero")

        elif decision == "talar":
            if self.habilidades["talar"]:
                self.actualizar_recurso("madera", 10, "Obtienes madera talando árboles")
            else:
                self.registrar_evento("No sabes talar aún, aprende la habilidad primero")

        else:
            self.registrar_evento("Esa acción no es válida")
    
    def actualizar_recurso(self, recurso, cantidad, mensaje):
        print(f"⚡ Evento: {mensaje} ({recurso.replace('_', ' ')}: {'+' if cantidad > 0 else ''}{cantidad})")
        self.recursos[recurso] += cantidad
        self.registrar_evento(mensaje)
        time.sleep(1)
        self.mostrar_estado()
        
    def registrar_evento(self, mensaje):
        self.eventos.append(mensaje)
        if len(self.eventos) > 10:
            self.eventos.pop(0)
        
    def jugar(self):
        print("🌍 ¡Bienvenido a la aventura de la supervivencia y evolución!\n")
        while self.epoca != "Edad Media":
            self.mostrar_estado()
            decision = input("¿Qué quieres hacer?: " ).lower()
            
            if decision == "salir":
                print("👋 Saliendo del juego... Hasta la próxima!\n")
                break
            elif decision == "avanzar":
                self.avanzar()
            else:
                self.tomar_decision(decision)
        
        if self.epoca == "Edad Media":
            print("🎉 ¡Has llegado a la Edad Media y evolucionado tu civilización!\n")

# Ejecutar el juego
if __name__ == "__main__":
    juego = JuegoSupervivencia()
    juego.jugar()
