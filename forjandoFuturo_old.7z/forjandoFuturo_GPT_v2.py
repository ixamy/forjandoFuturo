import time
import os

class JuegoSupervivencia:
    def __init__(self):
        self.epoca = "Prehistoria"
        self.recursos = {
            "comida_vegetal": 5, "comida_carne": 5, "madera": 5, "rocas": 3, "fibra_vegetal": 2,
            "agua": 5, "arcilla": 2, "herramientas": 0, "poblacion": 3
        }
        self.habilidades = {
            "cazar": False, "hacer_fuego": False, "construir": False, "forjar": False, 
            "agricultura": False, "pescar": False, "talar": False, "recolectar": False
        }
        self.eventos = []
    
    def mostrar_estado(self):
        os.system('cls' if os.name == 'nt' else 'clear')
        
        print(f"\n📜 Época actual: {self.epoca}\n")
        print("🌿 Recursos:")
        for k, v in self.recursos.items():
            print(f"   - {k.capitalize().replace('_', ' ')}: {v}")
        print("\n🛠️ Habilidades:")
        habilidades_str = ", ".join([k.replace('_', ' ') for k, v in self.habilidades.items() if v]) if any(self.habilidades.values()) else "Ninguna adquirida"
        print(f"   {habilidades_str}\n")
        
        print("📜 Eventos recientes:")
        for evento in self.eventos[-5:]:  # Mostrar los últimos 5 eventos
            print(f"   - {evento}")
        print("\n")
    
    def avanzar(self):
        if self.epoca == "Prehistoria" and self.habilidades["hacer_fuego"] and self.habilidades["cazar"] and self.recursos["poblacion"] >= 5:
            self.epoca = "Edad de Piedra"
            self.actualizar_recurso("herramientas", 2, "Descubriste herramientas rudimentarias de piedra")
        elif self.epoca == "Edad de Piedra" and self.habilidades["construir"] and self.habilidades["agricultura"] and self.recursos["poblacion"] >= 10:
            self.epoca = "Edad de los Metales"
            self.actualizar_recurso("madera", 10, "Aprendiste a construir viviendas más resistentes y cultivar alimentos")
        elif self.epoca == "Edad de los Metales" and self.habilidades["forjar"] and self.recursos["poblacion"] >= 15:
            self.epoca = "Edad Media"
            self.registrar_evento("Has dado paso a una sociedad con castillos y forja de armas")
        else:
            self.registrar_evento("Aún no puedes avanzar de época, necesitas más descubrimientos o más población")
    
    def tomar_decision(self, decision):
        if decision == "cazar":
            self.habilidades["cazar"] = True
            self.actualizar_recurso("comida_carne", 5, "Aprendiste a cazar, ahora obtienes más carne")
        elif decision == "hacer fuego":
            self.habilidades["hacer_fuego"] = True
            self.actualizar_recurso("madera", -1, "Hiciste fuego, consumiendo madera")
        elif decision == "construir":
            self.habilidades["construir"] = True
            self.actualizar_recurso("madera", 5, "Aprendiste a construir refugios más duraderos")
        elif decision == "forjar":
            self.habilidades["forjar"] = True
            self.actualizar_recurso("herramientas", 4, "Has aprendido a forjar metales, mejorando tus herramientas")
        elif decision == "agricultura":
            self.habilidades["agricultura"] = True
            self.actualizar_recurso("comida_vegetal", 10, "Has desarrollado la agricultura, mejorando tu producción de alimentos vegetales")
        elif decision == "pescar":
            self.habilidades["pescar"] = True
            self.actualizar_recurso("comida_carne", 4, "Has aprendido a pescar, obteniendo más carne")
        elif decision == "poblar":
            self.actualizar_recurso("poblacion", 2, "Tu población ha crecido, aumentando la fuerza de tu comunidad")
        elif decision == "talar":
            self.habilidades["talar"] = True
            self.actualizar_recurso("madera", 3, "Has aprendido a talar árboles, obteniendo más madera")
        elif decision == "recolectar":
            self.habilidades["recolectar"] = True
            self.actualizar_recurso("fibra_vegetal", 2, "Has aprendido a recolectar fibras vegetales")
        else:
            self.registrar_evento("Esa acción no es válida")
    
    def actualizar_recurso(self, recurso, cantidad, mensaje):
        print(f"⚡ Evento: {mensaje} ({recurso.replace('_', ' ')}: {'+' if cantidad > 0 else ''}{cantidad})")
        self.recursos[recurso] += cantidad
        self.registrar_evento(mensaje)
        time.sleep(1)
        self.mostrar_estado()  # Se vuelve a mostrar el estado actualizado
        
    def registrar_evento(self, mensaje):
        self.eventos.append(mensaje)
        if len(self.eventos) > 10:
            self.eventos.pop(0)  # Mantener solo los últimos 10 eventos en la lista
        
    def jugar(self):
        print("🌍 ¡Bienvenido a la aventura de la supervivencia y evolución!\n")
        while self.epoca != "Edad Media":
            self.mostrar_estado()
            try:
                decision = input("¿Qué quieres hacer? (cazar, hacer fuego, construir, forjar, agricultura, pescar, poblar, talar, recolectar, avanzar, salir): ").lower()
            except EOFError:
                print("⚠️ No se puede leer la entrada en este entorno. Usa una lista predefinida de decisiones.")
                break
            
            if decision == "salir":
                print("👋 Saliendo del juego... Hasta la próxima!\n")
                break
            elif decision == "avanzar":
                self.avanzar()
            else:
                self.tomar_decision(decision)
        if self.epoca == "Edad Media":
            print("🎉 ¡Has llegado a la Edad Media y evolucionado tu civilización!\n")

# Ejecutar el juego
if __name__ == "__main__":
    juego = JuegoSupervivencia()
    juego.jugar()
